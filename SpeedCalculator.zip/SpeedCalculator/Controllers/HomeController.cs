﻿using Microsoft.AspNetCore.Mvc;

namespace SpeedCalculator.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CalculateSpeed(double speed)
        {
            // Convert speed from m/s to km/h
            double speedInKmPerHour = speed * 3.6;

            // Pass the calculated speed to the view using ViewBag
            ViewBag.SpeedInKmPerHour = speedInKmPerHour;

            return View("Index");
        }
    }
}
